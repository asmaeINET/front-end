package com.tuscany.tour.models;

public enum TourStatus {
    ACTIVE, INACTIVE, DRAFT}