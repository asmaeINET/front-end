package com.tuscany.tour;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TourApplicationTests {

	@Test
	void contextLoads() {
	}

}
